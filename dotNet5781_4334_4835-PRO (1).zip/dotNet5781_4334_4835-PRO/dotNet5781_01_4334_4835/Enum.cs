﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5781_01_4334_4835
{
    public enum Choices // introducing the avilable actions
    {
        ADD, PICK, GAS_CHECKUP, TOTAL, EXIT = -1
    }
}

