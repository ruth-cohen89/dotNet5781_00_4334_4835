﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DS
{
   public static class RunningNumber
    {
       public static int RunningNumberID = 11;//running number for line
       public static int RunningTripID = 1;//we didnt use but it would have been for linetrip
        

    }
   
}
