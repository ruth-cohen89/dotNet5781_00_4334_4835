﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5781_00_4334_4835
{
    partial class Program
    {
        static partial void Welcome4334()
        {
            Console.WriteLine("Hello there!");
        }
    }
}
