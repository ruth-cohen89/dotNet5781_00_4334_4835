﻿namespace dotNet5781_02_4334_4835
{/*enum for areas*/
    public enum District
    {
        GENERAL, SOUTHERN, NORTHERN, CENTERAL, JERUSALEM
    }
    /*enum for user choices*/
    public enum CHOICE
    {
        ADD, DELETE, FIND, PRINT, EXIT = -1
    }
}
