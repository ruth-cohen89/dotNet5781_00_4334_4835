﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{

    public enum Areas { GENERAL, SOUTHERN, NORTHERN, CENTERAL, JERUSALEM }
    public enum BusStatus { Ready, In_the_middle, In_checkup, In_refuel };

}
