﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
   public class LineTrip
    {
        public int LineId { get; set; }//bus id
        public TimeSpan StartAt { get; set; }
       // public TimeSpan Frequency { get; set; }
        //public TimeSpan FinishAt { get; set; }
    }
}
